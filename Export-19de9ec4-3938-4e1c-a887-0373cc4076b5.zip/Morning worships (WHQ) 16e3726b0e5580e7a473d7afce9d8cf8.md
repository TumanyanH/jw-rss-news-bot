# Morning worships (WHQ)

[2024 Memorial Morning Worship—Kenneth Cook, Jr.: How Should We Remember Jesus? (Luke 22:19)](Morning%20worships%20(WHQ)%2016e3726b0e5580e7a473d7afce9d8cf8/2024%20Memorial%20Morning%20Worship%E2%80%94Kenneth%20Cook,%20Jr%20How%2016e3726b0e5581c9837ee6e6f9af9d64.md)

[Alex Reinmueller: A Balanced View of Guilt (2 Sam. 12:13)](Morning%20worships%20(WHQ)%2016e3726b0e5580e7a473d7afce9d8cf8/Alex%20Reinmueller%20A%20Balanced%20View%20of%20Guilt%20(2%20Sam%201%2016e3726b0e55814b9519ce0506a0b1d1.md)

[Alex Reinmueller: If Misjudged, Remain Loyal (1 Sam. 20:30)](Morning%20worships%20(WHQ)%2016e3726b0e5580e7a473d7afce9d8cf8/Alex%20Reinmueller%20If%20Misjudged,%20Remain%20Loyal%20(1%20Sam%2016e3726b0e5581dcb44bfd4d2a321062.md)

[Alex Reinmueller: "Jehovah Our God Is One Jehovah" (Deut. 6:4, 5)](Morning%20worships%20(WHQ)%2016e3726b0e5580e7a473d7afce9d8cf8/Alex%20Reinmueller%20Jehovah%20Our%20God%20Is%20One%20Jehovah%20(D%2016e3726b0e558105a2e7e08300fa4e70.md)

[Alex Reinmueller: Keep Up the Fight Against Sin! (Rom. 7:22, 23)](Morning%20worships%20(WHQ)%2016e3726b0e5580e7a473d7afce9d8cf8/Alex%20Reinmueller%20Keep%20Up%20the%20Fight%20Against%20Sin!%20(R%2016e3726b0e5581958818ef5b330872e0.md)

[Alex Reinmueller: Know Jehovah Better by Building Faith (Heb. 11:6)](Morning%20worships%20(WHQ)%2016e3726b0e5580e7a473d7afce9d8cf8/Alex%20Reinmueller%20Know%20Jehovah%20Better%20by%20Building%20F%2016e3726b0e5581b2b002ee513ed01d44.md)

[Anthony Griffin: Look Up and See (Isa. 40:26)](Morning%20worships%20(WHQ)%2016e3726b0e5580e7a473d7afce9d8cf8/Anthony%20Griffin%20Look%20Up%20and%20See%20(Isa%2040%2026)%2016e3726b0e558111a5ace3a0c0eb6e43.md)

[Anthony Griffin: The Refreshing Way Jehovah Deals With Us (Deut. 32:2)](Morning%20worships%20(WHQ)%2016e3726b0e5580e7a473d7afce9d8cf8/Anthony%20Griffin%20The%20Refreshing%20Way%20Jehovah%20Deals%20W%2016e3726b0e5581888c40ff8fb615f031.md)

[Baltasar Perla, Jr.: Acquire and Maintain Humility (1 Pet. 5:5)](Morning%20worships%20(WHQ)%2016e3726b0e5580e7a473d7afce9d8cf8/Baltasar%20Perla,%20Jr%20Acquire%20and%20Maintain%20Humility%20(%2016e3726b0e55811a94e9da1c2bbf1756.md)

[Baltasar Perla, Jr.: Jehovah Informs His People (Dan. 2:28)](Morning%20worships%20(WHQ)%2016e3726b0e5580e7a473d7afce9d8cf8/Baltasar%20Perla,%20Jr%20Jehovah%20Informs%20His%20People%20(Dan%2016e3726b0e558143b839e8e2d1912189.md)

[Betty Georges: “Go On Walking in Love” (Eph. 5:1, 2)](Morning%20worships%20(WHQ)%2016e3726b0e5580e7a473d7afce9d8cf8/Betty%20Georges%20%E2%80%9CGo%20On%20Walking%20in%20Love%E2%80%9D%20(Eph%205%201,%202)%2016e3726b0e5581a88a59e0b3b660184f.md)

[Christopher Mavor: Abraham—Jehovah’s Friend (Isa. 41:8)](Morning%20worships%20(WHQ)%2016e3726b0e5580e7a473d7afce9d8cf8/Christopher%20Mavor%20Abraham%E2%80%94Jehovah%E2%80%99s%20Friend%20(Isa%2041%2016e3726b0e5581d8a103d127106a9a47.md)

[Christopher Mavor: Draw Close to God Through Prayer (Eph. 6:18)](Morning%20worships%20(WHQ)%2016e3726b0e5580e7a473d7afce9d8cf8/Christopher%20Mavor%20Draw%20Close%20to%20God%20Through%20Prayer%2016e3726b0e558132b209e7d8d8f6d269.md)

[Christopher Mavor: Following Directions Saves Lives (Mark 13:19)](Morning%20worships%20(WHQ)%2016e3726b0e5580e7a473d7afce9d8cf8/Christopher%20Mavor%20Following%20Directions%20Saves%20Lives%2016e3726b0e5581b68e9cca12d74da84d.md)

[Christopher Mavor: Jehovah Loves His People (Isa. 54:5)](Morning%20worships%20(WHQ)%2016e3726b0e5580e7a473d7afce9d8cf8/Christopher%20Mavor%20Jehovah%20Loves%20His%20People%20(Isa%2054%2016e3726b0e5581d68386fb77f2c45291.md)

[Christopher Mavor: We Must Examine Our Motives (Prov. 16:2)](Morning%20worships%20(WHQ)%2016e3726b0e5580e7a473d7afce9d8cf8/Christopher%20Mavor%20We%20Must%20Examine%20Our%20Motives%20(Pro%2016e3726b0e558107bdf6e52f669be6c9.md)

[Clive Martin: Imitate Sarah’s Faith in Jehovah! (Heb. 11:11)](Morning%20worships%20(WHQ)%2016e3726b0e5580e7a473d7afce9d8cf8/Clive%20Martin%20Imitate%20Sarah%E2%80%99s%20Faith%20in%20Jehovah!%20(He%2016e3726b0e5581ceb02bd6627cfae31d.md)

[Clive Martin: Imitate the Humility of the Great Shepherd (Ps. 18:35)](Morning%20worships%20(WHQ)%2016e3726b0e5580e7a473d7afce9d8cf8/Clive%20Martin%20Imitate%20the%20Humility%20of%20the%20Great%20She%2016e3726b0e558126a794cf50dee16ad4.md)

[Clive Martin: Render Sacred Service With Godly Fear (Ps. 86:11, 12)](Morning%20worships%20(WHQ)%2016e3726b0e5580e7a473d7afce9d8cf8/Clive%20Martin%20Render%20Sacred%20Service%20With%20Godly%20Fear%2016e3726b0e5581559ee7f4e9cf62a445.md)

[Clive Martin: What Does Jehovah Look For in Us? (Prov. 27:11)](Morning%20worships%20(WHQ)%2016e3726b0e5580e7a473d7afce9d8cf8/Clive%20Martin%20What%20Does%20Jehovah%20Look%20For%20in%20Us%20(Pro%2016e3726b0e5581f3a773db993e6ea0e6.md)

[David H. Splane: “All Scripture Is Inspired” (2 Tim. 3:16)](Morning%20worships%20(WHQ)%2016e3726b0e5580e7a473d7afce9d8cf8/David%20H%20Splane%20%E2%80%9CAll%20Scripture%20Is%20Inspired%E2%80%9D%20(2%20Tim%20%2016e3726b0e558138977df601eb4bb38c.md)

[David H. Splane: Be Flexible for the Good News (1 Cor. 9:23)](Morning%20worships%20(WHQ)%2016e3726b0e5580e7a473d7afce9d8cf8/David%20H%20Splane%20Be%20Flexible%20for%20the%20Good%20News%20(1%20Co%2016e3726b0e558101937ff2974a829f04.md)

[David H. Splane: Blessings of JW.ORG (Isa. 60:16)](Morning%20worships%20(WHQ)%2016e3726b0e5580e7a473d7afce9d8cf8/David%20H%20Splane%20Blessings%20of%20JW%20ORG%20(Isa%2060%2016)%2016e3726b0e5581aaa68cf203af21416f.md)

[David H. Splane: Decisions of “the Faithful and Discreet Slave” (Matt. 24:45)](Morning%20worships%20(WHQ)%2016e3726b0e5580e7a473d7afce9d8cf8/David%20H%20Splane%20Decisions%20of%20%E2%80%9Cthe%20Faithful%20and%20Disc%2016e3726b0e5581dab7dde58609e171a4.md)

[David H. Splane: Hope in the Resurrection (Heb. 11:13)](Morning%20worships%20(WHQ)%2016e3726b0e5580e7a473d7afce9d8cf8/David%20H%20Splane%20Hope%20in%20the%20Resurrection%20(Heb%2011%2013%2016e3726b0e5581dd8f1bda62cb29dbf3.md)

[David H. Splane: I Do Not Know You (Matt. 25:12)](Morning%20worships%20(WHQ)%2016e3726b0e5580e7a473d7afce9d8cf8/David%20H%20Splane%20I%20Do%20Not%20Know%20You%20(Matt%2025%2012)%2016e3726b0e558119a10ff2bf960e5e98.md)

[David H. Splane: Inviting All to the Memorial (Ps. 118:22)](Morning%20worships%20(WHQ)%2016e3726b0e5580e7a473d7afce9d8cf8/David%20H%20Splane%20Inviting%20All%20to%20the%20Memorial%20(Ps%2011%2016e3726b0e55815cab83e9d15ea2d963.md)

[David H. Splane: Jehovah Will Never Abandon You (Gen. 39:2)](Morning%20worships%20(WHQ)%2016e3726b0e5580e7a473d7afce9d8cf8/David%20H%20Splane%20Jehovah%20Will%20Never%20Abandon%20You%20(Gen%2016e3726b0e55813db80cc974d967691d.md)

[David H. Splane: ‘Readjust Others in a Spirit of Mildness’ (Gal. 6:1)](Morning%20worships%20(WHQ)%2016e3726b0e5580e7a473d7afce9d8cf8/David%20H%20Splane%20%E2%80%98Readjust%20Others%20in%20a%20Spirit%20of%20Mil%2016e3726b0e558123a5b7eec2a54c844e.md)

[David H. Splane: “Safeguard Your Heart” (Prov. 4:23)](Morning%20worships%20(WHQ)%2016e3726b0e5580e7a473d7afce9d8cf8/David%20H%20Splane%20%E2%80%9CSafeguard%20Your%20Heart%E2%80%9D%20(Prov%204%2023)%2016e3726b0e5581829c84f9072ce7c601.md)

[David H. Splane: We Serve the God of True Prophecy (Ps. 46:8)](Morning%20worships%20(WHQ)%2016e3726b0e5580e7a473d7afce9d8cf8/David%20H%20Splane%20We%20Serve%20the%20God%20of%20True%20Prophecy%20(%2016e3726b0e5581b4985ed603ea6df4cb.md)

[David Schafer: “Be Absorbed in Them” (1 Tim. 4:15)](Morning%20worships%20(WHQ)%2016e3726b0e5580e7a473d7afce9d8cf8/David%20Schafer%20%E2%80%9CBe%20Absorbed%20in%20Them%E2%80%9D%20(1%20Tim%204%2015)%2016e3726b0e558162b0a3d499085e29f3.md)

[David Schafer: Every Word From Jehovah (Matt. 4:4)](Morning%20worships%20(WHQ)%2016e3726b0e5580e7a473d7afce9d8cf8/David%20Schafer%20Every%20Word%20From%20Jehovah%20(Matt%204%204)%2016e3726b0e5581e7bbaacc1f9d0ec391.md)

[David Schafer: Imitate Jehovah’s Generosity (1 Chron. 29:14)](Morning%20worships%20(WHQ)%2016e3726b0e5580e7a473d7afce9d8cf8/David%20Schafer%20Imitate%20Jehovah%E2%80%99s%20Generosity%20(1%20Chro%2016e3726b0e55813d808ae33d91d7bb4c.md)

[David Schafer: Jehovah Guides His People (Ps. 73:24)](Morning%20worships%20(WHQ)%2016e3726b0e5580e7a473d7afce9d8cf8/David%20Schafer%20Jehovah%20Guides%20His%20People%20(Ps%2073%2024)%2016e3726b0e55817980bdd4cade21facc.md)

[David Schafer: “Keep on the Watch” by Taking in Spiritual Food (Matt. 24:42-45)](Morning%20worships%20(WHQ)%2016e3726b0e5580e7a473d7afce9d8cf8/David%20Schafer%20%E2%80%9CKeep%20on%20the%20Watch%E2%80%9D%20by%20Taking%20in%20Spi%2016e3726b0e55817c8a52d7a4cb7e206f.md)

[David Schafer: Learn to Be Content (Heb. 13:5)](Morning%20worships%20(WHQ)%2016e3726b0e5580e7a473d7afce9d8cf8/David%20Schafer%20Learn%20to%20Be%20Content%20(Heb%2013%205)%2016e3726b0e558155b867ce2fccd60695.md)

[David Schafer: Micah Waited on Jehovah (Mic. 7:4)](Morning%20worships%20(WHQ)%2016e3726b0e5580e7a473d7afce9d8cf8/David%20Schafer%20Micah%20Waited%20on%20Jehovah%20(Mic%207%204)%2016e3726b0e558121b156faea94becb81.md)

[David Schafer: 'Practice Godly Devotion in Our Own Household' (1 Tim. 5:4)](Morning%20worships%20(WHQ)%2016e3726b0e5580e7a473d7afce9d8cf8/David%20Schafer%20'Practice%20Godly%20Devotion%20in%20Our%20Own%20%2016e3726b0e55815b9284d86ff059c759.md)

[David Schafer: Share a Word of Encouragement (Acts 13:15)](Morning%20worships%20(WHQ)%2016e3726b0e5580e7a473d7afce9d8cf8/David%20Schafer%20Share%20a%20Word%20of%20Encouragement%20(Acts%20%2016e3726b0e558188b7ffdfbd35284bf8.md)

[David Schafer: Survive the Great Day (Rev. 16:16)](Morning%20worships%20(WHQ)%2016e3726b0e5580e7a473d7afce9d8cf8/David%20Schafer%20Survive%20the%20Great%20Day%20(Rev%2016%2016)%2016e3726b0e55810ab536c37c36e9cb78.md)

[David Schafer: ‘Trust in Jehovah and Do Good’ (Ps. 37:3)](Morning%20worships%20(WHQ)%2016e3726b0e5580e7a473d7afce9d8cf8/David%20Schafer%20%E2%80%98Trust%20in%20Jehovah%20and%20Do%20Good%E2%80%99%20(Ps%203%2016e3726b0e558133b331e65650742474.md)

[David Schafer: We Live in the Time of the Harvest (Matt. 9:37)](Morning%20worships%20(WHQ)%2016e3726b0e5580e7a473d7afce9d8cf8/David%20Schafer%20We%20Live%20in%20the%20Time%20of%20the%20Harvest%20(%2016e3726b0e558157b983ef136a391a36.md)

[Donald Gordon: “Pay Constant Attention to .  .  . Your Teaching” (1 Tim. 4:16)](Morning%20worships%20(WHQ)%2016e3726b0e5580e7a473d7afce9d8cf8/Donald%20Gordon%20%E2%80%9CPay%20Constant%20Attention%20to%20Your%20Teac%2016e3726b0e5581b3acd5df45dd35b7da.md)

[Gage Fleegle: Benefiting From Prohibitions (Eccl. 7:9)](Morning%20worships%20(WHQ)%2016e3726b0e5580e7a473d7afce9d8cf8/Gage%20Fleegle%20Benefiting%20From%20Prohibitions%20(Eccl%207%20%2016e3726b0e558173afefce306af45311.md)

[Gage Fleegle: Jehovah’s Precious Gift, the Holy Spirit (John 3:34)](Morning%20worships%20(WHQ)%2016e3726b0e5580e7a473d7afce9d8cf8/Gage%20Fleegle%20Jehovah%E2%80%99s%20Precious%20Gift,%20the%20Holy%20Spi%2016e3726b0e558106a2b9d6078f83594a.md)

[Gajus Glockentin: How to Be Resilient (Luke 10:39)](Morning%20worships%20(WHQ)%2016e3726b0e5580e7a473d7afce9d8cf8/Gajus%20Glockentin%20How%20to%20Be%20Resilient%20(Luke%2010%2039)%2016e3726b0e5581a3971cc254d5c5ad57.md)

[Gajus Glockentin: Jehovah Remembers You (Heb. 6:10)](Morning%20worships%20(WHQ)%2016e3726b0e5580e7a473d7afce9d8cf8/Gajus%20Glockentin%20Jehovah%20Remembers%20You%20(Heb%206%2010)%2016e3726b0e5581379f84f30b876dfb53.md)

[Gajus Glockentin: ‘Make Friends by Means of Unrighteous Riches’ (Luke 16:9)](Morning%20worships%20(WHQ)%2016e3726b0e5580e7a473d7afce9d8cf8/Gajus%20Glockentin%20%E2%80%98Make%20Friends%20by%20Means%20of%20Unright%2016e3726b0e5581258139e3924d1b4e32.md)

[Gajus Glockentin: “Oppose the Devil” (Jas. 4:7)](Morning%20worships%20(WHQ)%2016e3726b0e5580e7a473d7afce9d8cf8/Gajus%20Glockentin%20%E2%80%9COppose%20the%20Devil%E2%80%9D%20(Jas%204%207)%2016e3726b0e5581c492e4c02fe3f0a08d.md)

[Gajus Glockentin: Protect Yourself From Lies (Col. 3:9)](Morning%20worships%20(WHQ)%2016e3726b0e5580e7a473d7afce9d8cf8/Gajus%20Glockentin%20Protect%20Yourself%20From%20Lies%20(Col%203%2016e3726b0e55811ea6aec8bea24da704.md)

[Gajus Glockentin: Reject Improper Instant Gratification (Titus 2:12)](Morning%20worships%20(WHQ)%2016e3726b0e5580e7a473d7afce9d8cf8/Gajus%20Glockentin%20Reject%20Improper%20Instant%20Gratifica%2016e3726b0e5581bca833c2f12c4e6550.md)

[Gajus Glockentin: The Ransom Protects Our Precious Unity (John 10:16)](Morning%20worships%20(WHQ)%2016e3726b0e5580e7a473d7afce9d8cf8/Gajus%20Glockentin%20The%20Ransom%20Protects%20Our%20Precious%20%2016e3726b0e5581d6b681ebb8c7b4ae51.md)

[Gajus Glockentin: Why Reach Out? (1 Tim. 3:1)](Morning%20worships%20(WHQ)%2016e3726b0e5580e7a473d7afce9d8cf8/Gajus%20Glockentin%20Why%20Reach%20Out%20(1%20Tim%203%201)%2016e3726b0e5581c68ad1f4280e3add79.md)

[Gary Breaux: In Awe of Jehovah (Josh. 9:9)](Morning%20worships%20(WHQ)%2016e3726b0e5580e7a473d7afce9d8cf8/Gary%20Breaux%20In%20Awe%20of%20Jehovah%20(Josh%209%209)%2016e3726b0e5581cbb477fd14b714150e.md)

[Gary Breaux: “Keep on the Watch” (Matt. 24:42)](Morning%20worships%20(WHQ)%2016e3726b0e5580e7a473d7afce9d8cf8/Gary%20Breaux%20%E2%80%9CKeep%20on%20the%20Watch%E2%80%9D%20(Matt%2024%2042)%2016e3726b0e558176ae8ff2402a8035e3.md)

[Gary Breaux: Let Jehovah Mold You (Isa. 64:8)](Morning%20worships%20(WHQ)%2016e3726b0e5580e7a473d7afce9d8cf8/Gary%20Breaux%20Let%20Jehovah%20Mold%20You%20(Isa%2064%208)%2016e3726b0e55816ea2cecf6e6e804a54.md)

[Gary Breaux: Let No One Take You Captive (Col. 2:8)](Morning%20worships%20(WHQ)%2016e3726b0e5580e7a473d7afce9d8cf8/Gary%20Breaux%20Let%20No%20One%20Take%20You%20Captive%20(Col%202%208)%2016e3726b0e55812eaba8e3b5639c5e68.md)

[Gary Breaux: Prepare Your Heart for Prayer (Ezra 7:10)](Morning%20worships%20(WHQ)%2016e3726b0e5580e7a473d7afce9d8cf8/Gary%20Breaux%20Prepare%20Your%20Heart%20for%20Prayer%20(Ezra%207%20%2016e3726b0e5581bfbd1dfed2f5050266.md)

[Gary Breaux: Protect Yourself From Misinformation (Dan. 11:27)](Morning%20worships%20(WHQ)%2016e3726b0e5580e7a473d7afce9d8cf8/Gary%20Breaux%20Protect%20Yourself%20From%20Misinformation%20(%2016e3726b0e55818989f9d489884ce463.md)

[Gary Breaux: Reasoning on Matters (2 Thess. 2:1, 2)](Morning%20worships%20(WHQ)%2016e3726b0e5580e7a473d7afce9d8cf8/Gary%20Breaux%20Reasoning%20on%20Matters%20(2%20Thess%202%201,%202)%2016e3726b0e5581729eb8f32a31dbb2b9.md)

[Gary Breaux: Satan’s Crafty Strategy (Gen. 3:1)](Morning%20worships%20(WHQ)%2016e3726b0e5580e7a473d7afce9d8cf8/Gary%20Breaux%20Satan%E2%80%99s%20Crafty%20Strategy%20(Gen%203%201)%2016e3726b0e558122a01bec60ad1980c7.md)

[Gary Breaux: Storytelling Is an Effective Teaching Tool (1 John 5:19)](Morning%20worships%20(WHQ)%2016e3726b0e5580e7a473d7afce9d8cf8/Gary%20Breaux%20Storytelling%20Is%20an%20Effective%20Teaching%20%2016e3726b0e558170a54eec0da59a33cf.md)

[Gary Breaux: The Older Men and the Superior Authorities Standing in Their Proper Place (Rom. 13:1-4)](Morning%20worships%20(WHQ)%2016e3726b0e5580e7a473d7afce9d8cf8/Gary%20Breaux%20The%20Older%20Men%20and%20the%20Superior%20Authori%2016e3726b0e5581a88844d63d2b63fa26.md)

[Gene Smalley: Do I Forgive Others? (Luke 18:11)](Morning%20worships%20(WHQ)%2016e3726b0e5580e7a473d7afce9d8cf8/Gene%20Smalley%20Do%20I%20Forgive%20Others%20(Luke%2018%2011)%2016e3726b0e5581a3a8b5e4b205b3daee.md)

[Geoffrey W. Jackson: "A Word Spoken at the Right Time" (Prov. 15:23)](Morning%20worships%20(WHQ)%2016e3726b0e5580e7a473d7afce9d8cf8/Geoffrey%20W%20Jackson%20A%20Word%20Spoken%20at%20the%20Right%20Time%2016e3726b0e55814da202e6b1d4f62c0b.md)

[Geoffrey W. Jackson: Assisting Our Brothers Materially (Prov. 19:17)](Morning%20worships%20(WHQ)%2016e3726b0e5580e7a473d7afce9d8cf8/Geoffrey%20W%20Jackson%20Assisting%20Our%20Brothers%20Material%2016e3726b0e5581808aa8f76fc1ec7d1d.md)

[Geoffrey W. Jackson: Be Faithful Like Abraham (Gen. 12:2)](Morning%20worships%20(WHQ)%2016e3726b0e5580e7a473d7afce9d8cf8/Geoffrey%20W%20Jackson%20Be%20Faithful%20Like%20Abraham%20(Gen%201%2016e3726b0e5581c98549d88f93024b16.md)

[Geoffrey W. Jackson: Be Transformed, Not Disguised (Rom. 12:2)](Morning%20worships%20(WHQ)%2016e3726b0e5580e7a473d7afce9d8cf8/Geoffrey%20W%20Jackson%20Be%20Transformed,%20Not%20Disguised%20(%2016e3726b0e5581e4a213e6cebc7d12e1.md)

[Geoffrey W. Jackson: “Christ Died for Us” (Rom. 5:8)](Morning%20worships%20(WHQ)%2016e3726b0e5580e7a473d7afce9d8cf8/Geoffrey%20W%20Jackson%20%E2%80%9CChrist%20Died%20for%20Us%E2%80%9D%20(Rom%205%208)%2016e3726b0e55812a9bafcfaf5d181297.md)

[Geoffrey W. Jackson: “Continue Putting Up With One Another” (Col. 3:13)](Morning%20worships%20(WHQ)%2016e3726b0e5580e7a473d7afce9d8cf8/Geoffrey%20W%20Jackson%20%E2%80%9CContinue%20Putting%20Up%20With%20One%20A%2016e3726b0e558185af38d4aa35d305c6.md)

[Geoffrey W. Jackson: Continue to "Be Transformed" (Rom. 12:2)](Morning%20worships%20(WHQ)%2016e3726b0e5580e7a473d7afce9d8cf8/Geoffrey%20W%20Jackson%20Continue%20to%20Be%20Transformed%20(Rom%2016e3726b0e558183b38cdd49c73eb43c.md)

[Geoffrey W. Jackson: Creating Opportunities to Give a Witness (John 4:6)](Morning%20worships%20(WHQ)%2016e3726b0e5580e7a473d7afce9d8cf8/Geoffrey%20W%20Jackson%20Creating%20Opportunities%20to%20Give%20%2016e3726b0e5581da9495cb2d2a3d16a6.md)

[Geoffrey W. Jackson: “Do All Things for God’s Glory” (1 Cor. 10:31)](Morning%20worships%20(WHQ)%2016e3726b0e5580e7a473d7afce9d8cf8/Geoffrey%20W%20Jackson%20%E2%80%9CDo%20All%20Things%20for%20God%E2%80%99s%20Glory%E2%80%9D%2016e3726b0e5581949c9ce07bd4b67ae7.md)

[Geoffrey W. Jackson: Elders Take the Lead! (Luke 8:1)](Morning%20worships%20(WHQ)%2016e3726b0e5580e7a473d7afce9d8cf8/Geoffrey%20W%20Jackson%20Elders%20Take%20the%20Lead!%20(Luke%208%201%2016e3726b0e5581ebb307ee1f07ae5f46.md)

[Geoffrey W. Jackson: Faithful With Material Things (Luke 16:9)](Morning%20worships%20(WHQ)%2016e3726b0e5580e7a473d7afce9d8cf8/Geoffrey%20W%20Jackson%20Faithful%20With%20Material%20Things%20(%2016e3726b0e558198b34bf04600cf635b.md)

[Geoffrey W. Jackson: Honor the Superior Authorities (Rom. 13:7)](Morning%20worships%20(WHQ)%2016e3726b0e5580e7a473d7afce9d8cf8/Geoffrey%20W%20Jackson%20Honor%20the%20Superior%20Authorities%20%2016e3726b0e5581a18b16f3fcc1e949e4.md)

[Geoffrey W. Jackson: Jesus Fulfilled the Law (Matt. 5:43)](Morning%20worships%20(WHQ)%2016e3726b0e5580e7a473d7afce9d8cf8/Geoffrey%20W%20Jackson%20Jesus%20Fulfilled%20the%20Law%20(Matt%205%2016e3726b0e55811ba597f3e8b187df0a.md)

[Geoffrey W. Jackson: Keep “the Belt of Truth” Tight (Eph. 6:14)](Morning%20worships%20(WHQ)%2016e3726b0e5580e7a473d7afce9d8cf8/Geoffrey%20W%20Jackson%20Keep%20%E2%80%9Cthe%20Belt%20of%20Truth%E2%80%9D%20Tight%20%2016e3726b0e5581ed8c26e1819b85a2ee.md)

[Geoffrey W. Jackson: Qualities of a Good Teacher (1 Thess. 2:7, 8)](Morning%20worships%20(WHQ)%2016e3726b0e5580e7a473d7afce9d8cf8/Geoffrey%20W%20Jackson%20Qualities%20of%20a%20Good%20Teacher%20(1%20%2016e3726b0e55812fbbd2e54b8d8c83bd.md)

[Geoffrey W. Jackson: Reaching "the Most Distant Part" (Acts 1:8)](Morning%20worships%20(WHQ)%2016e3726b0e5580e7a473d7afce9d8cf8/Geoffrey%20W%20Jackson%20Reaching%20the%20Most%20Distant%20Part%20%2016e3726b0e5581d78416e65c2d91b19a.md)

[Geoffrey W. Jackson: Testing Jehovah Out (Mal. 3:10)](Morning%20worships%20(WHQ)%2016e3726b0e5580e7a473d7afce9d8cf8/Geoffrey%20W%20Jackson%20Testing%20Jehovah%20Out%20(Mal%203%2010)%2016e3726b0e5581b89cbce5f49e3e3b35.md)

[Geoffrey W. Jackson: “The Meek Will Possess the Earth” (Ps. 37:11)](Morning%20worships%20(WHQ)%2016e3726b0e5580e7a473d7afce9d8cf8/Geoffrey%20W%20Jackson%20%E2%80%9CThe%20Meek%20Will%20Possess%20the%20Eart%2016e3726b0e5581e7b36cda31d07c8707.md)

[Geoffrey W. Jackson: Why Is Neutrality So Important? (Mic. 4:2)](Morning%20worships%20(WHQ)%2016e3726b0e5580e7a473d7afce9d8cf8/Geoffrey%20W%20Jackson%20Why%20Is%20Neutrality%20So%20Important%20%2016e3726b0e558161a946c420fd262aa9.md)

[Gerrit Lösch: Do Not Hold a Grudge (1 Cor. 13:8)](Morning%20worships%20(WHQ)%2016e3726b0e5580e7a473d7afce9d8cf8/Gerrit%20Lo%CC%88sch%20Do%20Not%20Hold%20a%20Grudge%20(1%20Cor%2013%208)%2016e3726b0e55811d82a7fd96e2423418.md)

[Harold Corkern: “Buy Truth and Never Sell It” (Prov. 23:23)](Morning%20worships%20(WHQ)%2016e3726b0e5580e7a473d7afce9d8cf8/Harold%20Corkern%20%E2%80%9CBuy%20Truth%20and%20Never%20Sell%20It%E2%80%9D%20(Prov%2016e3726b0e5581a5b75dd3a30cdf701d.md)

[Harold Corkern: Guard Your Relationship With Jehovah (Col. 3:5)](Morning%20worships%20(WHQ)%2016e3726b0e5580e7a473d7afce9d8cf8/Harold%20Corkern%20Guard%20Your%20Relationship%20With%20Jehova%2016e3726b0e5581eab073e06f5b7e37a0.md)

[Harold Corkern: Imitate God by Valuing Others and Their Work (Heb. 6:10)](Morning%20worships%20(WHQ)%2016e3726b0e5580e7a473d7afce9d8cf8/Harold%20Corkern%20Imitate%20God%20by%20Valuing%20Others%20and%20T%2016e3726b0e558109906feb9940c9a8b3.md)

[Harold Corkern: Imitate Jesus (John 2:25)](Morning%20worships%20(WHQ)%2016e3726b0e5580e7a473d7afce9d8cf8/Harold%20Corkern%20Imitate%20Jesus%20(John%202%2025)%2016e3726b0e55810dbe14c61ae5ec96ab.md)

[Harold Corkern: Jehovah—“The God of All Comfort” (2 Cor. 1:3, 4)](Morning%20worships%20(WHQ)%2016e3726b0e5580e7a473d7afce9d8cf8/Harold%20Corkern%20Jehovah%E2%80%94%E2%80%9CThe%20God%20of%20All%20Comfort%E2%80%9D%20(2%2016e3726b0e55818aa9a4d50fc4d7617f.md)

[Harold Corkern: Pray for “the Peace of God” (Phil. 4:7)](Morning%20worships%20(WHQ)%2016e3726b0e5580e7a473d7afce9d8cf8/Harold%20Corkern%20Pray%20for%20%E2%80%9Cthe%20Peace%20of%20God%E2%80%9D%20(Phil%204%2016e3726b0e5581f8869df6f4d5117c1c.md)

[Harold Corkern: Satan Cannot Fool Righteous Ones (2 Cor. 2:11)](Morning%20worships%20(WHQ)%2016e3726b0e5580e7a473d7afce9d8cf8/Harold%20Corkern%20Satan%20Cannot%20Fool%20Righteous%20Ones%20(2%2016e3726b0e55811686d8f083233a68b6.md)

[Harold Corkern: Stand Firm Against Our Enemy (1 Pet. 5:9)](Morning%20worships%20(WHQ)%2016e3726b0e5580e7a473d7afce9d8cf8/Harold%20Corkern%20Stand%20Firm%20Against%20Our%20Enemy%20(1%20Pet%2016e3726b0e558165bf37fce908e015f4.md)

[Harold Corkern: Willingly Love Your Brothers (1 Thess. 2:8)](Morning%20worships%20(WHQ)%2016e3726b0e5580e7a473d7afce9d8cf8/Harold%20Corkern%20Willingly%20Love%20Your%20Brothers%20(1%20The%2016e3726b0e5581e683cfc4f220ed7fbd.md)

[Hermanus van Selm: Be Faithful Like Noah (Gen. 6:13)](Morning%20worships%20(WHQ)%2016e3726b0e5580e7a473d7afce9d8cf8/Hermanus%20van%20Selm%20Be%20Faithful%20Like%20Noah%20(Gen%206%2013)%2016e3726b0e5581edbe4ce71ab7015106.md)

[Hermanus van Selm: Do Not Fear the Envious (Gen. 26:14, 15)](Morning%20worships%20(WHQ)%2016e3726b0e5580e7a473d7afce9d8cf8/Hermanus%20van%20Selm%20Do%20Not%20Fear%20the%20Envious%20(Gen%2026%20%2016e3726b0e5581f782b2dd38117f6026.md)

[Hermanus van Selm: Jehovah Cares for the Humble (Isa. 57:15)](Morning%20worships%20(WHQ)%2016e3726b0e5580e7a473d7afce9d8cf8/Hermanus%20van%20Selm%20Jehovah%20Cares%20for%20the%20Humble%20(Is%2016e3726b0e558146ae82c7693e4554a1.md)

[Hermanus van Selm: Obedience Is a Protection (2 Thess. 1:8)](Morning%20worships%20(WHQ)%2016e3726b0e5580e7a473d7afce9d8cf8/Hermanus%20van%20Selm%20Obedience%20Is%20a%20Protection%20(2%20The%2016e3726b0e55817fb495f33a00f5ad02.md)

[Hermanus van Selm: Our Heart and Jehovah’s Thinking (Ps. 119:97)](Morning%20worships%20(WHQ)%2016e3726b0e5580e7a473d7afce9d8cf8/Hermanus%20van%20Selm%20Our%20Heart%20and%20Jehovah%E2%80%99s%20Thinking%2016e3726b0e55813a9375ee7e77cbe53f.md)

[Hermanus van Selm: “Take Courage!” (John 16:33)](Morning%20worships%20(WHQ)%2016e3726b0e5580e7a473d7afce9d8cf8/Hermanus%20van%20Selm%20%E2%80%9CTake%20Courage!%E2%80%9D%20(John%2016%2033)%2016e3726b0e5581d4af77ef75a99f4197.md)

[Hermanus van Selm: The Connection Between Compassion and the Ransom (1 John 4:9-11)](Morning%20worships%20(WHQ)%2016e3726b0e5580e7a473d7afce9d8cf8/Hermanus%20van%20Selm%20The%20Connection%20Between%20Compassio%2016e3726b0e5581cc90ade58b69a5d900.md)

[Izak Marais: Always Be Gracious in Your Speech (Col. 4:6)](Morning%20worships%20(WHQ)%2016e3726b0e5580e7a473d7afce9d8cf8/Izak%20Marais%20Always%20Be%20Gracious%20in%20Your%20Speech%20(Col%2016e3726b0e55814dab38c993c2d23ff0.md)

[Izak Marais: Benefit From Jehovah’s Loving Discipline (Heb. 12:6)](Morning%20worships%20(WHQ)%2016e3726b0e5580e7a473d7afce9d8cf8/Izak%20Marais%20Benefit%20From%20Jehovah%E2%80%99s%20Loving%20Discipli%2016e3726b0e5581d8925bd26721d488bb.md)

[Izak Marais: "Deaden . . . Your Body Members" (Col. 3:5)](Morning%20worships%20(WHQ)%2016e3726b0e5580e7a473d7afce9d8cf8/Izak%20Marais%20Deaden%20Your%20Body%20Members%20(Col%203%205)%2016e3726b0e5581da822af41aa385d2c9.md)

[Izak Marais: How to Be a True Friend (Prov. 17:17)](Morning%20worships%20(WHQ)%2016e3726b0e5580e7a473d7afce9d8cf8/Izak%20Marais%20How%20to%20Be%20a%20True%20Friend%20(Prov%2017%2017)%2016e3726b0e5581069965cc6698ef5987.md)

[Izak Marais: Patiently Wait on Jehovah (Hab. 2:1)](Morning%20worships%20(WHQ)%2016e3726b0e5580e7a473d7afce9d8cf8/Izak%20Marais%20Patiently%20Wait%20on%20Jehovah%20(Hab%202%201)%2016e3726b0e55815b8636ee39e69c8710.md)

[Izak Marais: Seek First the Kingdom (Matt. 6:33)](Morning%20worships%20(WHQ)%2016e3726b0e5580e7a473d7afce9d8cf8/Izak%20Marais%20Seek%20First%20the%20Kingdom%20(Matt%206%2033)%2016e3726b0e5581c9afabe26dcd16d797.md)

[Izak Marais: “The Members . . . Are Necessary” (1 Cor. 12:22)](Morning%20worships%20(WHQ)%2016e3726b0e5580e7a473d7afce9d8cf8/Izak%20Marais%20%E2%80%9CThe%20Members%20Are%20Necessary%E2%80%9D%20(1%20Cor%2012%20%2016e3726b0e5581ecbb00e1dffa37539a.md)

[James Mantz: “All Things to People of All Sorts” (1 Cor. 9:22)](Morning%20worships%20(WHQ)%2016e3726b0e5580e7a473d7afce9d8cf8/James%20Mantz%20%E2%80%9CAll%20Things%20to%20People%20of%20All%20Sorts%E2%80%9D%20(1%2016e3726b0e5581a991aad959295dd40d.md)

[James Mantz: Avoid the Snare of Greed (Col. 3:5)](Morning%20worships%20(WHQ)%2016e3726b0e5580e7a473d7afce9d8cf8/James%20Mantz%20Avoid%20the%20Snare%20of%20Greed%20(Col%203%205)%2016e3726b0e55816a8631d84d294af839.md)

[James Mantz: “Do Not Be Quick to Take Offense” (Eccl. 7:9)](Morning%20worships%20(WHQ)%2016e3726b0e5580e7a473d7afce9d8cf8/James%20Mantz%20%E2%80%9CDo%20Not%20Be%20Quick%20to%20Take%20Offense%E2%80%9D%20(Ecc%2016e3726b0e558141a363fb779488bd57.md)

[James Mantz: Guard Against Greed (Luke 12:15)](Morning%20worships%20(WHQ)%2016e3726b0e5580e7a473d7afce9d8cf8/James%20Mantz%20Guard%20Against%20Greed%20(Luke%2012%2015)%2016e3726b0e558196a786df18ca6f4049.md)

[James Mantz: Jehovah Is Our Potter (Isa. 64:8)](Morning%20worships%20(WHQ)%2016e3726b0e5580e7a473d7afce9d8cf8/James%20Mantz%20Jehovah%20Is%20Our%20Potter%20(Isa%2064%208)%2016e3726b0e558197b9e1c495def1e800.md)

[James Mantz: Jehovah Provides True Freedom (2 Cor. 3:17)](Morning%20worships%20(WHQ)%2016e3726b0e5580e7a473d7afce9d8cf8/James%20Mantz%20Jehovah%20Provides%20True%20Freedom%20(2%20Cor%203%2016e3726b0e558196a86ad7a209a52d37.md)

[James Mantz: “Make Friends . . . by Means of Unrighteous Riches” (Luke 16:9)](Morning%20worships%20(WHQ)%2016e3726b0e5580e7a473d7afce9d8cf8/James%20Mantz%20%E2%80%9CMake%20Friends%20by%20Means%20of%20Unrighteous%20%2016e3726b0e5581918eded8582bad5eef.md)

[James Mantz: Using Our Mental Capacity to the Full (Deut. 6:7)](Morning%20worships%20(WHQ)%2016e3726b0e5580e7a473d7afce9d8cf8/James%20Mantz%20Using%20Our%20Mental%20Capacity%20to%20the%20Full%20%2016e3726b0e5581fa8f69f835125ca531.md)

[Jeffrey Winder: Headship—A Perfect Arrangement (1 Cor. 14:40)](Morning%20worships%20(WHQ)%2016e3726b0e5580e7a473d7afce9d8cf8/Jeffrey%20Winder%20Headship%E2%80%94A%20Perfect%20Arrangement%20(1%20C%2016e3726b0e55813f8e60fd2aba02189d.md)

[Jeffrey Winder: Our Modesty Benefits Others (Matt. 22:39)](Morning%20worships%20(WHQ)%2016e3726b0e5580e7a473d7afce9d8cf8/Jeffrey%20Winder%20Our%20Modesty%20Benefits%20Others%20(Matt%202%2016e3726b0e5581b4bc40e8ee7ace62f9.md)

[Joel Dellinger: “Always Rejoice in the Lord” (Phil. 4:4)](Morning%20worships%20(WHQ)%2016e3726b0e5580e7a473d7afce9d8cf8/Joel%20Dellinger%20%E2%80%9CAlways%20Rejoice%20in%20the%20Lord%E2%80%9D%20(Phil%20%2016e3726b0e55813cb9a0cecc3f957755.md)

[Joel Dellinger: Be a Discerning Student (Prov. 3:13)](Morning%20worships%20(WHQ)%2016e3726b0e5580e7a473d7afce9d8cf8/Joel%20Dellinger%20Be%20a%20Discerning%20Student%20(Prov%203%2013)%2016e3726b0e5581ab8bc5ed9532cb0cf4.md)

[Joel Dellinger: Be Transformed by Training the Conscience (1 Tim. 1:5)](Morning%20worships%20(WHQ)%2016e3726b0e5580e7a473d7afce9d8cf8/Joel%20Dellinger%20Be%20Transformed%20by%20Training%20the%20Cons%2016e3726b0e5581288d8cea1194672634.md)

[Joel Dellinger: Cannot Slave for Two Masters (Matt. 6:24)](Morning%20worships%20(WHQ)%2016e3726b0e5580e7a473d7afce9d8cf8/Joel%20Dellinger%20Cannot%20Slave%20for%20Two%20Masters%20(Matt%20%2016e3726b0e558188a775c943c5d885cf.md)

[Joel Dellinger: Cooperation Builds Unity (Luke 2:41)](Morning%20worships%20(WHQ)%2016e3726b0e5580e7a473d7afce9d8cf8/Joel%20Dellinger%20Cooperation%20Builds%20Unity%20(Luke%202%2041%2016e3726b0e5581e6b9efc922a5e4258d.md)

[Joel Dellinger: Endurance—Essential to Stay in the Truth (2 Tim. 4:7, 8)](Morning%20worships%20(WHQ)%2016e3726b0e5580e7a473d7afce9d8cf8/Joel%20Dellinger%20Endurance%E2%80%94Essential%20to%20Stay%20in%20the%20%2016e3726b0e5581a1b715de978f92db15.md)

[Joel Dellinger: Faith—"Assured Expectation" (Heb. 11:1)](Morning%20worships%20(WHQ)%2016e3726b0e5580e7a473d7afce9d8cf8/Joel%20Dellinger%20Faith%E2%80%94%20Assured%20Expectation%20(Heb%2011%20%2016e3726b0e558164bac1e920f9ced77b.md)

[Joel Dellinger: Jehovah’s Day “Will Not Be Late!” (Hab. 2:3)](Morning%20worships%20(WHQ)%2016e3726b0e5580e7a473d7afce9d8cf8/Joel%20Dellinger%20Jehovah%E2%80%99s%20Day%20%E2%80%9CWill%20Not%20Be%20Late!%E2%80%9D%20(%2016e3726b0e55813c8105ec5f54b5eeaa.md)

[Joel Dellinger: Maintain a Waiting Attitude (Matt. 18:14)](Morning%20worships%20(WHQ)%2016e3726b0e5580e7a473d7afce9d8cf8/Joel%20Dellinger%20Maintain%20a%20Waiting%20Attitude%20(Matt%201%2016e3726b0e5581e58349f3420b7ce3b4.md)

[Joel Dellinger: Moving Forward With Faith, Not Fear (Isa. 41:10)](Morning%20worships%20(WHQ)%2016e3726b0e5580e7a473d7afce9d8cf8/Joel%20Dellinger%20Moving%20Forward%20With%20Faith,%20Not%20Fear%2016e3726b0e5581e6b31bc887dde7bacb.md)

[Joel Dellinger: Strengthen Our Hope (Rev. 21:4)](Morning%20worships%20(WHQ)%2016e3726b0e5580e7a473d7afce9d8cf8/Joel%20Dellinger%20Strengthen%20Our%20Hope%20(Rev%2021%204)%2016e3726b0e55817f9f40e421a312e508.md)

[Joel Dellinger: Understanding Prophecy Motivates Us (Rev. 7:9)](Morning%20worships%20(WHQ)%2016e3726b0e5580e7a473d7afce9d8cf8/Joel%20Dellinger%20Understanding%20Prophecy%20Motivates%20Us%2016e3726b0e5581c28afef14b96e11acf.md)

[Joel Dellinger: Your Deliverance Is Getting Near (Rev. 6:15)](Morning%20worships%20(WHQ)%2016e3726b0e5580e7a473d7afce9d8cf8/Joel%20Dellinger%20Your%20Deliverance%20Is%20Getting%20Near%20(R%2016e3726b0e5581bdb13dd0bd2c6048ea.md)

[John Ekrann: Be Clay in Jehovah’s Hands (Rom. 12:2)](Morning%20worships%20(WHQ)%2016e3726b0e5580e7a473d7afce9d8cf8/John%20Ekrann%20Be%20Clay%20in%20Jehovah%E2%80%99s%20Hands%20(Rom%2012%202)%2016e3726b0e558165a96acb7b75aa2e21.md)

[John Ekrann: Become Gentle to One Another (1 Thess. 2:7)](Morning%20worships%20(WHQ)%2016e3726b0e5580e7a473d7afce9d8cf8/John%20Ekrann%20Become%20Gentle%20to%20One%20Another%20(1%20Thess%20%2016e3726b0e55818e8cb8c458c1d860c6.md)

[John Ekrann: "Become Imitators of God" (Eph. 5:1)](Morning%20worships%20(WHQ)%2016e3726b0e5580e7a473d7afce9d8cf8/John%20Ekrann%20Become%20Imitators%20of%20God%20(Eph%205%201)%2016e3726b0e5581c1aeb8d47ca2118122.md)

[John Ekrann: Build Faith in the Resurrection (Acts 9:40)](Morning%20worships%20(WHQ)%2016e3726b0e5580e7a473d7afce9d8cf8/John%20Ekrann%20Build%20Faith%20in%20the%20Resurrection%20(Acts%20%2016e3726b0e5581af85bdeabc348e26c5.md)

[John Ekrann: Do You See Jehovah’s Hand? (Isa. 66:14)](Morning%20worships%20(WHQ)%2016e3726b0e5580e7a473d7afce9d8cf8/John%20Ekrann%20Do%20You%20See%20Jehovah%E2%80%99s%20Hand%20(Isa%2066%2014)%2016e3726b0e5581c89803ec973bf9c632.md)

[John Ekrann: How Can We Successfully Overcome Misunderstandings? (Acts 15:37-39)](Morning%20worships%20(WHQ)%2016e3726b0e5580e7a473d7afce9d8cf8/John%20Ekrann%20How%20Can%20We%20Successfully%20Overcome%20Misun%2016e3726b0e5581e2b9e6cd4ea220d9ed.md)

[John Ekrann: “Lovers of Money” (2 Tim. 3:2)](Morning%20worships%20(WHQ)%2016e3726b0e5580e7a473d7afce9d8cf8/John%20Ekrann%20%E2%80%9CLovers%20of%20Money%E2%80%9D%20(2%20Tim%203%202)%2016e3726b0e5581bcb536c49ce4a1c297.md)

[John Ekrann: Stick to Jehovah’s Requirements, and Obey Theocratic Direction (Acts 15:1)](Morning%20worships%20(WHQ)%2016e3726b0e5580e7a473d7afce9d8cf8/John%20Ekrann%20Stick%20to%20Jehovah%E2%80%99s%20Requirements,%20and%20O%2016e3726b0e5581ab9942fff64e0e80a6.md)

[John Ekrann: “Taste” the Ransom (Gal. 2:20)](Morning%20worships%20(WHQ)%2016e3726b0e5580e7a473d7afce9d8cf8/John%20Ekrann%20%E2%80%9CTaste%E2%80%9D%20the%20Ransom%20(Gal%202%2020)%2016e3726b0e5581399bd8f93bca696dc6.md)

[John Ekrann: The True Religion Unites Christ’s Followers (Jer. 6:16)](Morning%20worships%20(WHQ)%2016e3726b0e5580e7a473d7afce9d8cf8/John%20Ekrann%20The%20True%20Religion%20Unites%20Christ%E2%80%99s%20Foll%2016e3726b0e5581daaba2f9ed01abec97.md)

[Jonathan Smith: Better Days Ahead (Eccl. 7:10)](Morning%20worships%20(WHQ)%2016e3726b0e5580e7a473d7afce9d8cf8/Jonathan%20Smith%20Better%20Days%20Ahead%20(Eccl%207%2010)%2016e3726b0e55812b913bce200573e171.md)

[Jonathan Smith: See the Bigger Picture (1 Sam. 17:42)](Morning%20worships%20(WHQ)%2016e3726b0e5580e7a473d7afce9d8cf8/Jonathan%20Smith%20See%20the%20Bigger%20Picture%20(1%20Sam%2017%2042%2016e3726b0e5581f29ee7e78724b460c3.md)

[Kenneth Cook, Jr.: Avoid Deception, and Follow the Kingdom (Jer. 10:23)](Morning%20worships%20(WHQ)%2016e3726b0e5580e7a473d7afce9d8cf8/Kenneth%20Cook,%20Jr%20Avoid%20Deception,%20and%20Follow%20the%20K%2016e3726b0e5581fba8c4e6a6f27c9f24.md)

[Kenneth Cook, Jr: Everlasting Life Is Worth Any Sacrifice (Mark 10:29, 30)](Morning%20worships%20(WHQ)%2016e3726b0e5580e7a473d7afce9d8cf8/Kenneth%20Cook,%20Jr%20Everlasting%20Life%20Is%20Worth%20Any%20Sac%2016e3726b0e558125888bfabf68faaf50.md)

[Kenneth Cook, Jr.: “Hold Fast to What You Have Until I Come” (Rev. 2:25)](Morning%20worships%20(WHQ)%2016e3726b0e5580e7a473d7afce9d8cf8/Kenneth%20Cook,%20Jr%20%E2%80%9CHold%20Fast%20to%20What%20You%20Have%20Until%2016e3726b0e5581f393f2e67d22f7db58.md)

[Kenneth Cook, Jr.: Jehovah Is Near to His Worshippers (Ps. 139:1-4)](Morning%20worships%20(WHQ)%2016e3726b0e5580e7a473d7afce9d8cf8/Kenneth%20Cook,%20Jr%20Jehovah%20Is%20Near%20to%20His%20Worshipper%2016e3726b0e5581dd8a23c1b03876ecff.md)

[Kenneth Cook, Jr.: Keep Promises, Receive Blessings (Ps. 15:4)](Morning%20worships%20(WHQ)%2016e3726b0e5580e7a473d7afce9d8cf8/Kenneth%20Cook,%20Jr%20Keep%20Promises,%20Receive%20Blessings%20%2016e3726b0e55817388f7e9a7a2e4d848.md)

[Kenneth Flodin: “Better Is the End of a Matter” (Eccl. 7:8)](Morning%20worships%20(WHQ)%2016e3726b0e5580e7a473d7afce9d8cf8/Kenneth%20Flodin%20%E2%80%9CBetter%20Is%20the%20End%20of%20a%20Matter%E2%80%9D%20(Ec%2016e3726b0e55819bae45ceae09cbf5e1.md)

[Kenneth Flodin: Beware of Deceit (Jude 9)](Morning%20worships%20(WHQ)%2016e3726b0e5580e7a473d7afce9d8cf8/Kenneth%20Flodin%20Beware%20of%20Deceit%20(Jude%209)%2016e3726b0e558172bd3de611ee19b303.md)

[Kenneth Flodin: ‘Do Good and Share’ (Heb. 13:16)](Morning%20worships%20(WHQ)%2016e3726b0e5580e7a473d7afce9d8cf8/Kenneth%20Flodin%20%E2%80%98Do%20Good%20and%20Share%E2%80%99%20(Heb%2013%2016)%2016e3726b0e5581ff9f39d707c7d0575c.md)

[Kenneth Flodin: Humble or Haughty? (Jas. 4:6)](Morning%20worships%20(WHQ)%2016e3726b0e5580e7a473d7afce9d8cf8/Kenneth%20Flodin%20Humble%20or%20Haughty%20(Jas%204%206)%2016e3726b0e5581b7a700d09ed622c9fd.md)

[Kenneth Flodin: ‘Jesus’ Yoke Is Kindly’ (Matt. 11:29, 30)](Morning%20worships%20(WHQ)%2016e3726b0e5580e7a473d7afce9d8cf8/Kenneth%20Flodin%20%E2%80%98Jesus%E2%80%99%20Yoke%20Is%20Kindly%E2%80%99%20(Matt%2011%2029%2016e3726b0e55819e9b8ce8afb4e3c2b3.md)

[Kenneth Flodin: Learn From Errors (Phil. 3:13)](Morning%20worships%20(WHQ)%2016e3726b0e5580e7a473d7afce9d8cf8/Kenneth%20Flodin%20Learn%20From%20Errors%20(Phil%203%2013)%2016e3726b0e558140950ccf8d5d36bb32.md)

[Kenneth Flodin: Neutral in the Ministry (Matt. 10:16)](Morning%20worships%20(WHQ)%2016e3726b0e5580e7a473d7afce9d8cf8/Kenneth%20Flodin%20Neutral%20in%20the%20Ministry%20(Matt%2010%2016%2016e3726b0e55817091d1ca1b2af70d6b.md)

[Kenneth Flodin: “The Plans of the Diligent” (Prov. 21:5)](Morning%20worships%20(WHQ)%2016e3726b0e5580e7a473d7afce9d8cf8/Kenneth%20Flodin%20%E2%80%9CThe%20Plans%20of%20the%20Diligent%E2%80%9D%20(Prov%202%2016e3726b0e55813bb5b2d7f054ec03e7.md)

[Kenneth Flodin: The Quality of Meekness (Num. 12:3)](Morning%20worships%20(WHQ)%2016e3726b0e5580e7a473d7afce9d8cf8/Kenneth%20Flodin%20The%20Quality%20of%20Meekness%20(Num%2012%203)%2016e3726b0e5581838ea6c8be54ba086a.md)

[Kenneth Flodin: Walk by Spirit (Gal. 5:16)](Morning%20worships%20(WHQ)%2016e3726b0e5580e7a473d7afce9d8cf8/Kenneth%20Flodin%20Walk%20by%20Spirit%20(Gal%205%2016)%2016e3726b0e558102bf28ef14f7f9f8b6.md)

[Kenneth Godburn: Listen With Mildness (Jas. 1:19-21)](Morning%20worships%20(WHQ)%2016e3726b0e5580e7a473d7afce9d8cf8/Kenneth%20Godburn%20Listen%20With%20Mildness%20(Jas%201%2019-21)%2016e3726b0e5581d69fd6f73757c9f37d.md)

[Kenneth Godburn: Loyal Support for Christ’s Brothers (Matt. 25:40)](Morning%20worships%20(WHQ)%2016e3726b0e5580e7a473d7afce9d8cf8/Kenneth%20Godburn%20Loyal%20Support%20for%20Christ%E2%80%99s%20Brother%2016e3726b0e5581088920f359834ed18c.md)

[Leon Weaver, Jr.: Don’t Give Up in Preaching—Circumstances Change (Acts 16:26-31)](Morning%20worships%20(WHQ)%2016e3726b0e5580e7a473d7afce9d8cf8/Leon%20Weaver,%20Jr%20Don%E2%80%99t%20Give%20Up%20in%20Preaching%E2%80%94Circums%2016e3726b0e5581368579f0c8e345b27e.md)

[Leonard Myers: Be Reasonable in the Family (Col. 3:18-20)](Morning%20worships%20(WHQ)%2016e3726b0e5580e7a473d7afce9d8cf8/Leonard%20Myers%20Be%20Reasonable%20in%20the%20Family%20(Col%203%201%2016e3726b0e5581799c85dd09d992264c.md)

[Leonard Myers: “Have . . . Concern for One Another” (1 Cor. 12:25)](Morning%20worships%20(WHQ)%2016e3726b0e5580e7a473d7afce9d8cf8/Leonard%20Myers%20%E2%80%9CHave%20Concern%20for%20One%20Another%E2%80%9D%20(1%20Co%2016e3726b0e5581428073f197971b63b0.md)

[Leonard Myers: Jehovah Rewards His Faithful Servants (Heb. 11:6)](Morning%20worships%20(WHQ)%2016e3726b0e5580e7a473d7afce9d8cf8/Leonard%20Myers%20Jehovah%20Rewards%20His%20Faithful%20Servant%2016e3726b0e5581948d7fc915a65547c2.md)

[Leonard Myers: Remain Watchful for “Peace and Security!” (1 Thess. 5:3)](Morning%20worships%20(WHQ)%2016e3726b0e5580e7a473d7afce9d8cf8/Leonard%20Myers%20Remain%20Watchful%20for%20%E2%80%9CPeace%20and%20Secur%2016e3726b0e5581f78594ea535eb3550c.md)

[Leonard Myers: Show Love to Unbelieving Relatives While Being Loyal to Jehovah (Matt. 10:34, 35)](Morning%20worships%20(WHQ)%2016e3726b0e5580e7a473d7afce9d8cf8/Leonard%20Myers%20Show%20Love%20to%20Unbelieving%20Relatives%20W%2016e3726b0e5581d983baf4598c29eb6e.md)

[Leonard Myers: The Transfiguration Builds Faith (2 Pet. 1:19)](Morning%20worships%20(WHQ)%2016e3726b0e5580e7a473d7afce9d8cf8/Leonard%20Myers%20The%20Transfiguration%20Builds%20Faith%20(2%20%2016e3726b0e5581d8b7c4f676f9c4f317.md)

[M. Stephen Lett: Avoid Murmuring (Jas. 3:5)](Morning%20worships%20(WHQ)%2016e3726b0e5580e7a473d7afce9d8cf8/M%20Stephen%20Lett%20Avoid%20Murmuring%20(Jas%203%205)%2016e3726b0e5581e2a14ac432ffe39090.md)

[M. Stephen Lett: Beware of the Power of Materialism (Matt. 6:11)](Morning%20worships%20(WHQ)%2016e3726b0e5580e7a473d7afce9d8cf8/M%20Stephen%20Lett%20Beware%20of%20the%20Power%20of%20Materialism%20%2016e3726b0e5581a0abd4dc28dd2cdb5d.md)

[M. Stephen Lett: “Draw Close to God” (Jas. 4:8)](Morning%20worships%20(WHQ)%2016e3726b0e5580e7a473d7afce9d8cf8/M%20Stephen%20Lett%20%E2%80%9CDraw%20Close%20to%20God%E2%80%9D%20(Jas%204%208)%2016e3726b0e55811aaf54d51f8d1c5d49.md)

[M. Stephen Lett: "Guard Against Every Sort of Greed" (Jer. 45:5)](Morning%20worships%20(WHQ)%2016e3726b0e5580e7a473d7afce9d8cf8/M%20Stephen%20Lett%20Guard%20Against%20Every%20Sort%20of%20Greed%20(%2016e3726b0e5581deb2b6fa1640848257.md)

[M. Stephen Lett: Help Young Ones Progress (Mark 10:13, 14)](Morning%20worships%20(WHQ)%2016e3726b0e5580e7a473d7afce9d8cf8/M%20Stephen%20Lett%20Help%20Young%20Ones%20Progress%20(Mark%2010%201%2016e3726b0e5581d0b68ac0ee5afa1dc0.md)

[M. Stephen Lett: Husbands, Love Your Wife as Yourself (Song of Sol. 8:6)](Morning%20worships%20(WHQ)%2016e3726b0e5580e7a473d7afce9d8cf8/M%20Stephen%20Lett%20Husbands,%20Love%20Your%20Wife%20as%20Yoursel%2016e3726b0e5581ddb782c165e2a4ade1.md)

[M. Stephen Lett: Jehovah’s Hand Is Awe-Inspiring! (Ps. 145:16)](Morning%20worships%20(WHQ)%2016e3726b0e5580e7a473d7afce9d8cf8/M%20Stephen%20Lett%20Jehovah%E2%80%99s%20Hand%20Is%20Awe-Inspiring!%20(P%2016e3726b0e558170a33cc8f23c723149.md)

[M. Stephen Lett: Listen With Understanding (Matt. 13:16)](Morning%20worships%20(WHQ)%2016e3726b0e5580e7a473d7afce9d8cf8/M%20Stephen%20Lett%20Listen%20With%20Understanding%20(Matt%2013%20%2016e3726b0e55813ab35becfea7674b55.md)

[M. Stephen Lett: Never Be a Cause for Stumbling (2 Cor. 6:3)](Morning%20worships%20(WHQ)%2016e3726b0e5580e7a473d7afce9d8cf8/M%20Stephen%20Lett%20Never%20Be%20a%20Cause%20for%20Stumbling%20(2%20C%2016e3726b0e558151a2a4e2e7bad1bad8.md)

[M. Stephen Lett: Never Let Satan Intimidate You (Deut. 1:17)](Morning%20worships%20(WHQ)%2016e3726b0e5580e7a473d7afce9d8cf8/M%20Stephen%20Lett%20Never%20Let%20Satan%20Intimidate%20You%20(Deu%2016e3726b0e558185ae4dd29c76fa50a1.md)

[M. Stephen Lett: Pride Is Before a Crash (Prov. 16:18)](Morning%20worships%20(WHQ)%2016e3726b0e5580e7a473d7afce9d8cf8/M%20Stephen%20Lett%20Pride%20Is%20Before%20a%20Crash%20(Prov%2016%2018%2016e3726b0e5581a18343ed375bc35b17.md)

[M. Stephen Lett: Pursue the Way of Love (1 John 3:18)](Morning%20worships%20(WHQ)%2016e3726b0e5580e7a473d7afce9d8cf8/M%20Stephen%20Lett%20Pursue%20the%20Way%20of%20Love%20(1%20John%203%2018%2016e3726b0e5581fd9576e3fb0a59cced.md)

[M. Stephen Lett: See the Big Picture (Acts 8:5)](Morning%20worships%20(WHQ)%2016e3726b0e5580e7a473d7afce9d8cf8/M%20Stephen%20Lett%20See%20the%20Big%20Picture%20(Acts%208%205)%2016e3726b0e5581d784c9edecf8b0050f.md)

[M. Stephen Lett: Show Favor to Lowly Ones (Prov. 19:17)](Morning%20worships%20(WHQ)%2016e3726b0e5580e7a473d7afce9d8cf8/M%20Stephen%20Lett%20Show%20Favor%20to%20Lowly%20Ones%20(Prov%2019%201%2016e3726b0e558199bb04f2556d5acb24.md)

[M. Stephen Lett: Tap Into "the Power Beyond What Is Normal" (2 Cor. 4:7)](Morning%20worships%20(WHQ)%2016e3726b0e5580e7a473d7afce9d8cf8/M%20Stephen%20Lett%20Tap%20Into%20the%20Power%20Beyond%20What%20Is%20N%2016e3726b0e55819a8d7eda8a1a2c9551.md)

[M. Stephen Lett: Why Did Israel Go to War, but Why Don’t Christians Today? (1 John 3:10-12)](Morning%20worships%20(WHQ)%2016e3726b0e5580e7a473d7afce9d8cf8/M%20Stephen%20Lett%20Why%20Did%20Israel%20Go%20to%20War,%20but%20Why%20D%2016e3726b0e55811e9643f7ff87853b97.md)

[M. Stephen Lett: Win the Inner Struggle (Rom. 7:23)](Morning%20worships%20(WHQ)%2016e3726b0e5580e7a473d7afce9d8cf8/M%20Stephen%20Lett%20Win%20the%20Inner%20Struggle%20(Rom%207%2023)%2016e3726b0e5581798f2bed612f7704bc.md)

[Mark Noumair: Deep Study Draws Us Close to Jehovah (Ps. 73:28)](Morning%20worships%20(WHQ)%2016e3726b0e5580e7a473d7afce9d8cf8/Mark%20Noumair%20Deep%20Study%20Draws%20Us%20Close%20to%20Jehovah%20%2016e3726b0e5581118fc3c4a46929fb06.md)

[Mark Noumair: Don’t Miss Clear Evidence (Isa. 8:10)](Morning%20worships%20(WHQ)%2016e3726b0e5580e7a473d7afce9d8cf8/Mark%20Noumair%20Don%E2%80%99t%20Miss%20Clear%20Evidence%20(Isa%208%2010)%2016e3726b0e558186bfedd1a79c6fd331.md)

[Mark Noumair: “Ezra Had Prepared His Heart” (Ezra 7:10)](Morning%20worships%20(WHQ)%2016e3726b0e5580e7a473d7afce9d8cf8/Mark%20Noumair%20%E2%80%9CEzra%20Had%20Prepared%20His%20Heart%E2%80%9D%20(Ezra%207%2016e3726b0e5581398d00c81cf04151a3.md)

[Mark Noumair: He Used His Body to Honor Jehovah (1 Cor. 11:24)](Morning%20worships%20(WHQ)%2016e3726b0e5580e7a473d7afce9d8cf8/Mark%20Noumair%20He%20Used%20His%20Body%20to%20Honor%20Jehovah%20(1%20%2016e3726b0e55810b97ffd7e0024e8503.md)

[Mark Noumair: “It Will Not Be Late!” (Hab. 2:3)](Morning%20worships%20(WHQ)%2016e3726b0e5580e7a473d7afce9d8cf8/Mark%20Noumair%20%E2%80%9CIt%20Will%20Not%20Be%20Late!%E2%80%9D%20(Hab%202%203)%2016e3726b0e5581ffbb2ad804a9898076.md)

[Mark Noumair: Jehovah Encourages His Servant (Jer. 15:16)](Morning%20worships%20(WHQ)%2016e3726b0e5580e7a473d7afce9d8cf8/Mark%20Noumair%20Jehovah%20Encourages%20His%20Servant%20(Jer%201%2016e3726b0e558146b56bd922aef02802.md)

[Mark Noumair: Jehovah Is With Them (Zech. 8:23)](Morning%20worships%20(WHQ)%2016e3726b0e5580e7a473d7afce9d8cf8/Mark%20Noumair%20Jehovah%20Is%20With%20Them%20(Zech%208%2023)%2016e3726b0e558180845bcc9e04a6826e.md)

[Mark Noumair: Keep Spinning on the Potter’s Wheel (Josh. 1:1, 2)](Morning%20worships%20(WHQ)%2016e3726b0e5580e7a473d7afce9d8cf8/Mark%20Noumair%20Keep%20Spinning%20on%20the%20Potter%E2%80%99s%20Wheel%20(%2016e3726b0e5581738c1fd510d648cb48.md)

[Mark Noumair: Our Witnessing Conquers Satan (Rev. 12:9)](Morning%20worships%20(WHQ)%2016e3726b0e5580e7a473d7afce9d8cf8/Mark%20Noumair%20Our%20Witnessing%20Conquers%20Satan%20(Rev%2012%2016e3726b0e5581238624cd918d5ac4c1.md)

[Mark Noumair: Pray for Integrity (Matt. 26:2)](Morning%20worships%20(WHQ)%2016e3726b0e5580e7a473d7afce9d8cf8/Mark%20Noumair%20Pray%20for%20Integrity%20(Matt%2026%202)%2016e3726b0e55814eabf5dd37ba0887c1.md)

[Mark Noumair: Prepare for Persecution (1 Pet. 4:4)](Morning%20worships%20(WHQ)%2016e3726b0e5580e7a473d7afce9d8cf8/Mark%20Noumair%20Prepare%20for%20Persecution%20(1%20Pet%204%204)%2016e3726b0e55812ab09ecbb2e1597afd.md)

[Mark Noumair: Show Humility (1 Pet. 5:5)](Morning%20worships%20(WHQ)%2016e3726b0e5580e7a473d7afce9d8cf8/Mark%20Noumair%20Show%20Humility%20(1%20Pet%205%205)%2016e3726b0e55814087a9c186587c8dc7.md)

[Mark Noumair: “This Is the Way” (Isa. 30:21)](Morning%20worships%20(WHQ)%2016e3726b0e5580e7a473d7afce9d8cf8/Mark%20Noumair%20%E2%80%9CThis%20Is%20the%20Way%E2%80%9D%20(Isa%2030%2021)%2016e3726b0e558111ade4c8a9c654cf7c.md)

[Mark Sanderson: Be Prepared (Jas. 4:14)](Morning%20worships%20(WHQ)%2016e3726b0e5580e7a473d7afce9d8cf8/Mark%20Sanderson%20Be%20Prepared%20(Jas%204%2014)%2016e3726b0e55810b8a9ac6ac8a91c98b.md)

[Mark Sanderson: Can We Speed Up His Day? (2 Pet. 3:​11)](Morning%20worships%20(WHQ)%2016e3726b0e5580e7a473d7afce9d8cf8/Mark%20Sanderson%20Can%20We%20Speed%20Up%20His%20Day%20(2%20Pet%203%20%E2%80%8B1%2016e3726b0e55814eb891c40eb96c797b.md)

[Mark Sanderson: Focus on the Inner Person (Ps. 51:6)](Morning%20worships%20(WHQ)%2016e3726b0e5580e7a473d7afce9d8cf8/Mark%20Sanderson%20Focus%20on%20the%20Inner%20Person%20(Ps%2051%206)%2016e3726b0e5581c4abc2e2e955a25c78.md)

[Mark Sanderson: “I Give You My Peace” (John 14:27)](Morning%20worships%20(WHQ)%2016e3726b0e5580e7a473d7afce9d8cf8/Mark%20Sanderson%20%E2%80%9CI%20Give%20You%20My%20Peace%E2%80%9D%20(John%2014%2027)%2016e3726b0e5581b2896ffd4ad2b92e5b.md)

[Mark Sanderson: Jehovah Supports the Sick (Acts 15:29)](Morning%20worships%20(WHQ)%2016e3726b0e5580e7a473d7afce9d8cf8/Mark%20Sanderson%20Jehovah%20Supports%20the%20Sick%20(Acts%2015%20%2016e3726b0e558139b96fec5aa9dfaf36.md)

[Mark Sanderson: Keep the Mental Attitude of Christ (Phil. 2:5, 7)](Morning%20worships%20(WHQ)%2016e3726b0e5580e7a473d7afce9d8cf8/Mark%20Sanderson%20Keep%20the%20Mental%20Attitude%20of%20Christ%20%2016e3726b0e5581fd8fa8e9a43d74f289.md)

[Mark Sanderson: ‘Peace of God Surpasses Understanding’ (Phil. 4:6, 7)](Morning%20worships%20(WHQ)%2016e3726b0e5580e7a473d7afce9d8cf8/Mark%20Sanderson%20%E2%80%98Peace%20of%20God%20Surpasses%20Understandi%2016e3726b0e55819997e1ffc798ead104.md)

[Mark Sanderson: Seek the Advantage of the Other Person (1 Cor. 10:23)](Morning%20worships%20(WHQ)%2016e3726b0e5580e7a473d7afce9d8cf8/Mark%20Sanderson%20Seek%20the%20Advantage%20of%20the%20Other%20Per%2016e3726b0e558153bde6d9ebacd8a645.md)

[Mark Sanderson: “Take Your Stand Against Him” (1 Pet. 5:9)](Morning%20worships%20(WHQ)%2016e3726b0e5580e7a473d7afce9d8cf8/Mark%20Sanderson%20%E2%80%9CTake%20Your%20Stand%20Against%20Him%E2%80%9D%20(1%20Pe%2016e3726b0e558193ac2af0d56c5cadfd.md)

[Mark Sanderson: They Proved Themselves Faultless (1 Ki. 15:5)](Morning%20worships%20(WHQ)%2016e3726b0e5580e7a473d7afce9d8cf8/Mark%20Sanderson%20They%20Proved%20Themselves%20Faultless%20(1%2016e3726b0e55819aabd9e5b0af9942cc.md)

[Mark Sanderson: They Would Be Objects of Persecution (Matt. 10:22)](Morning%20worships%20(WHQ)%2016e3726b0e5580e7a473d7afce9d8cf8/Mark%20Sanderson%20They%20Would%20Be%20Objects%20of%20Persecutio%2016e3726b0e55818faaa9df9db423279f.md)

[Mark Sanderson: “Wisdom Is With the Modest Ones” (Prov. 11:2)](Morning%20worships%20(WHQ)%2016e3726b0e5580e7a473d7afce9d8cf8/Mark%20Sanderson%20%E2%80%9CWisdom%20Is%20With%20the%20Modest%20Ones%E2%80%9D%20(P%2016e3726b0e5581639ddfdc2c6914e423.md)

[Memorial Morning Worship—Gerrit Lösch: Jehovah Restores His Original Purpose (Gen. 2:15-17)](Morning%20worships%20(WHQ)%2016e3726b0e5580e7a473d7afce9d8cf8/Memorial%20Morning%20Worship%E2%80%94Gerrit%20Lo%CC%88sch%20Jehovah%20Res%2016e3726b0e5581e1acdaefb85519ed5b.md)

[Memorial Morning Worship—M. Stephen Lett: “The Spirit Itself Bears Witness With Our Spirit” (Rom. 8:16)](Morning%20worships%20(WHQ)%2016e3726b0e5580e7a473d7afce9d8cf8/Memorial%20Morning%20Worship%E2%80%94M%20Stephen%20Lett%20%E2%80%9CThe%20Spiri%2016e3726b0e5581d78610c3a1a35ada27.md)

[Memorial Morning Worship—Samuel F. Herd: Annually, “Keep Doing This in Remembrance of Me” (Luke 22:19)](Morning%20worships%20(WHQ)%2016e3726b0e5580e7a473d7afce9d8cf8/Memorial%20Morning%20Worship%E2%80%94Samuel%20F%20Herd%20Annually,%20%E2%80%9C%2016e3726b0e5581c284bae0fbe82c2341.md)

[Nicholas Ahladis: Jehovah Cares for the “Little Ones” (Matt. 18:10)](Morning%20worships%20(WHQ)%2016e3726b0e5580e7a473d7afce9d8cf8/Nicholas%20Ahladis%20Jehovah%20Cares%20for%20the%20%E2%80%9CLittle%20One%2016e3726b0e5581bbadf4cbf07ff5b925.md)

[Patrick LaFranca: Continue to Acquire Wisdom Each Day (Prov. 3:15)](Morning%20worships%20(WHQ)%2016e3726b0e5580e7a473d7afce9d8cf8/Patrick%20LaFranca%20Continue%20to%20Acquire%20Wisdom%20Each%20D%2016e3726b0e5581cf83a0e58c39b1c521.md)

[Patrick LaFranca: ‘Remember Those Taking the Lead’ (Heb. 13:7)](Morning%20worships%20(WHQ)%2016e3726b0e5580e7a473d7afce9d8cf8/Patrick%20LaFranca%20%E2%80%98Remember%20Those%20Taking%20the%20Lead%E2%80%99%20%2016e3726b0e55814a9ee7dde9cfddcfc3.md)

[Patrick LaFranca: ‘Remember Your Grand Creator’ (Eccl. 12:1)](Morning%20worships%20(WHQ)%2016e3726b0e5580e7a473d7afce9d8cf8/Patrick%20LaFranca%20%E2%80%98Remember%20Your%20Grand%20Creator%E2%80%99%20(Ec%2016e3726b0e5581f98001f9564a3425bf.md)

[Paul Gillies: Reflect Jehovah’s Personality by Imitating Jesus (Eph. 4:20, 21)](Morning%20worships%20(WHQ)%2016e3726b0e5580e7a473d7afce9d8cf8/Paul%20Gillies%20Reflect%20Jehovah%E2%80%99s%20Personality%20by%20Imit%2016e3726b0e558155aa74fd183c6caa45.md)

[Per Christensen: Seeing and Remembering Helps Us Endure (Matt. 17:5)](Morning%20worships%20(WHQ)%2016e3726b0e5580e7a473d7afce9d8cf8/Per%20Christensen%20Seeing%20and%20Remembering%20Helps%20Us%20En%2016e3726b0e55819a9994c3bf038e4fe6.md)

[Ralph Walls: Be Forgiving (Rom. 5:12)](Morning%20worships%20(WHQ)%2016e3726b0e5580e7a473d7afce9d8cf8/Ralph%20Walls%20Be%20Forgiving%20(Rom%205%2012)%2016e3726b0e5581ed8233fa8c558060a3.md)

[Ralph Walls: “Ponder Over These Things” (1 Tim. 4:15)](Morning%20worships%20(WHQ)%2016e3726b0e5580e7a473d7afce9d8cf8/Ralph%20Walls%20%E2%80%9CPonder%20Over%20These%20Things%E2%80%9D%20(1%20Tim%204%2015%2016e3726b0e5581de92dfe65bf9afdb02.md)

[Ralph Walls: Protect Your Thinking Ability (2 Cor. 10:4, 5)](Morning%20worships%20(WHQ)%2016e3726b0e5580e7a473d7afce9d8cf8/Ralph%20Walls%20Protect%20Your%20Thinking%20Ability%20(2%20Cor%201%2016e3726b0e558133a65dfe53cbe31bda.md)

[Robert Ciranko: Avoid Flirting and Ego (1 Tim. 5:2)](Morning%20worships%20(WHQ)%2016e3726b0e5580e7a473d7afce9d8cf8/Robert%20Ciranko%20Avoid%20Flirting%20and%20Ego%20(1%20Tim%205%202)%2016e3726b0e55817086aee3795de4cda7.md)

[Robert Ciranko: Discern Satan’s Lies (Gen. 3:15)](Morning%20worships%20(WHQ)%2016e3726b0e5580e7a473d7afce9d8cf8/Robert%20Ciranko%20Discern%20Satan%E2%80%99s%20Lies%20(Gen%203%2015)%2016e3726b0e558126a633c45a9d7df92c.md)

[Robert Ciranko: Discipline Is From Jehovah (1 Cor. 5:11)](Morning%20worships%20(WHQ)%2016e3726b0e5580e7a473d7afce9d8cf8/Robert%20Ciranko%20Discipline%20Is%20From%20Jehovah%20(1%20Cor%205%2016e3726b0e558158b196c5fcef336964.md)

[Robert Ciranko: God’s People Glorify His Name (1 Pet. 2:10)](Morning%20worships%20(WHQ)%2016e3726b0e5580e7a473d7afce9d8cf8/Robert%20Ciranko%20God%E2%80%99s%20People%20Glorify%20His%20Name%20(1%20Pe%2016e3726b0e55811eabb5c6be4e7447be.md)

[Robert Ciranko: How to Be a True Friend (Matt. 7:12)](Morning%20worships%20(WHQ)%2016e3726b0e5580e7a473d7afce9d8cf8/Robert%20Ciranko%20How%20to%20Be%20a%20True%20Friend%20(Matt%207%2012)%2016e3726b0e55819685f8db5395cf7dab.md)

[Robert Ciranko: Jehovah Guards Loyal Ones (Ps. 97:10)](Morning%20worships%20(WHQ)%2016e3726b0e5580e7a473d7afce9d8cf8/Robert%20Ciranko%20Jehovah%20Guards%20Loyal%20Ones%20(Ps%2097%2010%2016e3726b0e5581fda3d2e7d74609b171.md)

[Robert Ciranko: Jesus Is Wisdom Personified (Prov. 8:30)](Morning%20worships%20(WHQ)%2016e3726b0e5580e7a473d7afce9d8cf8/Robert%20Ciranko%20Jesus%20Is%20Wisdom%20Personified%20(Prov%208%2016e3726b0e5581e29f97da964b5c326f.md)

[Robert Ciranko: “They Will Become One Flesh” (Gen. 2:24)](Morning%20worships%20(WHQ)%2016e3726b0e5580e7a473d7afce9d8cf8/Robert%20Ciranko%20%E2%80%9CThey%20Will%20Become%20One%20Flesh%E2%80%9D%20(Gen%202%2016e3726b0e558196a3b6e3465878dc50.md)

[Robert Luccioni: Accomplishing Assignments Jehovah’s Way (John 5:19)](Morning%20worships%20(WHQ)%2016e3726b0e5580e7a473d7afce9d8cf8/Robert%20Luccioni%20Accomplishing%20Assignments%20Jehovah%E2%80%99%2016e3726b0e5581769a56f5bacceb12b4.md)

[Robert Luccioni: Another Convenient Time (Luke 4:6)](Morning%20worships%20(WHQ)%2016e3726b0e5580e7a473d7afce9d8cf8/Robert%20Luccioni%20Another%20Convenient%20Time%20(Luke%204%206)%2016e3726b0e558111ac33e267f8a27eaf.md)

[Robert Luccioni: Be a Gideon (Eph. 4:1, 2)](Morning%20worships%20(WHQ)%2016e3726b0e5580e7a473d7afce9d8cf8/Robert%20Luccioni%20Be%20a%20Gideon%20(Eph%204%201,%202)%2016e3726b0e5581b1acb0d08fd7555759.md)

[Robert Luccioni: Be Determined to Endure (Luke 8:15)](Morning%20worships%20(WHQ)%2016e3726b0e5580e7a473d7afce9d8cf8/Robert%20Luccioni%20Be%20Determined%20to%20Endure%20(Luke%208%2015%2016e3726b0e55813e8d50ca5089675f77.md)

[Robert Luccioni: Develop the Tongue of the Wise Ones (Prov. 12:18)](Morning%20worships%20(WHQ)%2016e3726b0e5580e7a473d7afce9d8cf8/Robert%20Luccioni%20Develop%20the%20Tongue%20of%20the%20Wise%20One%2016e3726b0e558110a9e8d1ff42ca8dd5.md)

[Robert Luccioni: “Do Not Forget Hospitality” (Heb. 13:2)](Morning%20worships%20(WHQ)%2016e3726b0e5580e7a473d7afce9d8cf8/Robert%20Luccioni%20%E2%80%9CDo%20Not%20Forget%20Hospitality%E2%80%9D%20(Heb%201%2016e3726b0e5581c0a1c3f1dedadd367f.md)

[Robert Luccioni: “Do You Believe This?” (John 11:26)](Morning%20worships%20(WHQ)%2016e3726b0e5580e7a473d7afce9d8cf8/Robert%20Luccioni%20%E2%80%9CDo%20You%20Believe%20This%20%E2%80%9D%20(John%2011%2026%2016e3726b0e558152b5ead93020cb1143.md)

[Robert Luccioni: Don’t Limit Your Potential (Amos 7:​14)](Morning%20worships%20(WHQ)%2016e3726b0e5580e7a473d7afce9d8cf8/Robert%20Luccioni%20Don%E2%80%99t%20Limit%20Your%20Potential%20(Amos%207%2016e3726b0e55817f99e2f68efb2b736a.md)

[Robert Luccioni: Guard Yourself Respecting a Treacherous Spirit (Mal. 2:15)](Morning%20worships%20(WHQ)%2016e3726b0e5580e7a473d7afce9d8cf8/Robert%20Luccioni%20Guard%20Yourself%20Respecting%20a%20Treach%2016e3726b0e5581b1807ee36e9f831758.md)

[Robert Luccioni: Have Humility and Peace (Phil. 2:3)](Morning%20worships%20(WHQ)%2016e3726b0e5580e7a473d7afce9d8cf8/Robert%20Luccioni%20Have%20Humility%20and%20Peace%20(Phil%202%203)%2016e3726b0e5581f3810ace30d3346a8e.md)

[Robert Luccioni: “Pressing on Toward the Goal” (Phil. 3:14)](Morning%20worships%20(WHQ)%2016e3726b0e5580e7a473d7afce9d8cf8/Robert%20Luccioni%20%E2%80%9CPressing%20on%20Toward%20the%20Goal%E2%80%9D%20(Phi%2016e3726b0e55810d81decedf28467c8d.md)

[Robert Luccioni: Principles for Persecution (John 15:20)](Morning%20worships%20(WHQ)%2016e3726b0e5580e7a473d7afce9d8cf8/Robert%20Luccioni%20Principles%20for%20Persecution%20(John%201%2016e3726b0e5581e499c1f7b18d7de568.md)

[Robert Luccioni: “Source of Living Water” (Jer. 2:13)](Morning%20worships%20(WHQ)%2016e3726b0e5580e7a473d7afce9d8cf8/Robert%20Luccioni%20%E2%80%9CSource%20of%20Living%20Water%E2%80%9D%20(Jer%202%2013%2016e3726b0e558191ade7e6fefa5d257f.md)

[Robert Luccioni: Strengthen Your Spiritual Core (2 Tim. 3:13)](Morning%20worships%20(WHQ)%2016e3726b0e5580e7a473d7afce9d8cf8/Robert%20Luccioni%20Strengthen%20Your%20Spiritual%20Core%20(2%20%2016e3726b0e5581578cbcdae53533e5ba.md)

[Robert Luccioni: Think God's Thoughts, Not Those of Men (Matt. 16:23)](Morning%20worships%20(WHQ)%2016e3726b0e5580e7a473d7afce9d8cf8/Robert%20Luccioni%20Think%20God's%20Thoughts,%20Not%20Those%20of%2016e3726b0e5581979cd8da96db2e93c3.md)

[Ronald Curzan: Be “a True Friend” (Prov. 17:17)](Morning%20worships%20(WHQ)%2016e3726b0e5580e7a473d7afce9d8cf8/Ronald%20Curzan%20Be%20%E2%80%9Ca%20True%20Friend%E2%80%9D%20(Prov%2017%2017)%2016e3726b0e55810ca155d43f27663c81.md)

[Ronald Curzan: Be Acceptable to Jehovah (Eph. 5:10)](Morning%20worships%20(WHQ)%2016e3726b0e5580e7a473d7afce9d8cf8/Ronald%20Curzan%20Be%20Acceptable%20to%20Jehovah%20(Eph%205%2010)%2016e3726b0e558179a4e7cb3ff8c4dde6.md)

[Ronald Curzan: “Dwell Together in Unity!” (Ps. 133:1)](Morning%20worships%20(WHQ)%2016e3726b0e5580e7a473d7afce9d8cf8/Ronald%20Curzan%20%E2%80%9CDwell%20Together%20in%20Unity!%E2%80%9D%20(Ps%20133%201%2016e3726b0e558104ad47e5ff21ee98a6.md)

[Ronald Curzan: Jehovah’s Name Is Sanctified (Matt. 6:9)](Morning%20worships%20(WHQ)%2016e3726b0e5580e7a473d7afce9d8cf8/Ronald%20Curzan%20Jehovah%E2%80%99s%20Name%20Is%20Sanctified%20(Matt%206%2016e3726b0e5581eda4c4ff32aa619dda.md)

[Ronald Curzan: Marriage Mates “Become One Flesh” (Gen. 2:24)](Morning%20worships%20(WHQ)%2016e3726b0e5580e7a473d7afce9d8cf8/Ronald%20Curzan%20Marriage%20Mates%20%E2%80%9CBecome%20One%20Flesh%E2%80%9D%20(G%2016e3726b0e5581419c2aff7724c56560.md)

[Ronald Curzan: Our Hope of the Resurrection (Acts 24:15)](Morning%20worships%20(WHQ)%2016e3726b0e5580e7a473d7afce9d8cf8/Ronald%20Curzan%20Our%20Hope%20of%20the%20Resurrection%20(Acts%202%2016e3726b0e5581c3908df5369e4767a1.md)

[Ronald Curzan: Show Appreciation for All of Jehovah’s Provisions  (Ps. 116:1)](Morning%20worships%20(WHQ)%2016e3726b0e5580e7a473d7afce9d8cf8/Ronald%20Curzan%20Show%20Appreciation%20for%20All%20of%20Jehovah%2016e3726b0e5581808092dc53f897aa25.md)

[Ronald Curzan: Starve Your Distraction, Feed Your Focus (Luke 12:14)](Morning%20worships%20(WHQ)%2016e3726b0e5580e7a473d7afce9d8cf8/Ronald%20Curzan%20Starve%20Your%20Distraction,%20Feed%20Your%20F%2016e3726b0e5581d3bdddc9708e6d6128.md)

[Samuel F. Herd: Draw Close to Jehovah (Jas. 4:8)](Morning%20worships%20(WHQ)%2016e3726b0e5580e7a473d7afce9d8cf8/Samuel%20F%20Herd%20Draw%20Close%20to%20Jehovah%20(Jas%204%208)%2016e3726b0e55815d8565c450ebf0031e.md)

[Samuel F. Herd: “I Was Given a Thorn in the Flesh” (2 Cor. 12:7)](Morning%20worships%20(WHQ)%2016e3726b0e5580e7a473d7afce9d8cf8/Samuel%20F%20Herd%20%E2%80%9CI%20Was%20Given%20a%20Thorn%20in%20the%20Flesh%E2%80%9D%20(%2016e3726b0e5581e5aa62cec1bfa54951.md)

[Samuel F. Herd: Jehovah Does Not Forget Your Love (Ps. 71:18)](Morning%20worships%20(WHQ)%2016e3726b0e5580e7a473d7afce9d8cf8/Samuel%20F%20Herd%20Jehovah%20Does%20Not%20Forget%20Your%20Love%20(P%2016e3726b0e5581f898e0fe24c92e6ea2.md)

[Samuel F. Herd: Slave for Jehovah—A Cherished Privilege (Matt. 24:45)](Morning%20worships%20(WHQ)%2016e3726b0e5580e7a473d7afce9d8cf8/Samuel%20F%20Herd%20Slave%20for%20Jehovah%E2%80%94A%20Cherished%20Privil%2016e3726b0e55818486fddb4b54a177bd.md)

[Seth Hyatt: “Bear Fruit With Endurance” Despite Trials (Luke 8:15)](Morning%20worships%20(WHQ)%2016e3726b0e5580e7a473d7afce9d8cf8/Seth%20Hyatt%20%E2%80%9CBear%20Fruit%20With%20Endurance%E2%80%9D%20Despite%20Tri%2016e3726b0e5581bda147edc5eda4062c.md)

[Seth Hyatt: Choose “the Good Portion” (Luke 10:42)](Morning%20worships%20(WHQ)%2016e3726b0e5580e7a473d7afce9d8cf8/Seth%20Hyatt%20Choose%20%E2%80%9Cthe%20Good%20Portion%E2%80%9D%20(Luke%2010%2042)%2016e3726b0e558152aa84f930e07d3e2c.md)

[Seth Hyatt: Give Gifts of Mercy (Luke 10:37)](Morning%20worships%20(WHQ)%2016e3726b0e5580e7a473d7afce9d8cf8/Seth%20Hyatt%20Give%20Gifts%20of%20Mercy%20(Luke%2010%2037)%2016e3726b0e55817dab72e9e63ca39cc8.md)

[Seth Hyatt: Humility and Contentment (Phil. 1:10)](Morning%20worships%20(WHQ)%2016e3726b0e5580e7a473d7afce9d8cf8/Seth%20Hyatt%20Humility%20and%20Contentment%20(Phil%201%2010)%2016e3726b0e5581a195bff4b722aa523a.md)

[Seth Hyatt: Lacking Good Sense (Prov. 5:8)](Morning%20worships%20(WHQ)%2016e3726b0e5580e7a473d7afce9d8cf8/Seth%20Hyatt%20Lacking%20Good%20Sense%20(Prov%205%208)%2016e3726b0e55812babeff4a55a53b50f.md)

[Seth Hyatt: Make Decisions With Jehovah (2 Chron. 16:9)](Morning%20worships%20(WHQ)%2016e3726b0e5580e7a473d7afce9d8cf8/Seth%20Hyatt%20Make%20Decisions%20With%20Jehovah%20(2%20Chron%2016%2016e3726b0e55818fbbf0ecfc88e1d602.md)

[Seth Hyatt: Speaking Truth Though Labeled as Deceivers (2 Cor. 6:8)](Morning%20worships%20(WHQ)%2016e3726b0e5580e7a473d7afce9d8cf8/Seth%20Hyatt%20Speaking%20Truth%20Though%20Labeled%20as%20Deceiv%2016e3726b0e5581379a3bd79cc93d1bf2.md)

[Seth Hyatt: Uphold Jehovah’s View of Marriage (Mark 10:11, 12)](Morning%20worships%20(WHQ)%2016e3726b0e5580e7a473d7afce9d8cf8/Seth%20Hyatt%20Uphold%20Jehovah%E2%80%99s%20View%20of%20Marriage%20(Mark%2016e3726b0e5581f0b72bc508586323ae.md)

[Troy Snyder: Help for the Discouraged (Ps. 34:18)](Morning%20worships%20(WHQ)%2016e3726b0e5580e7a473d7afce9d8cf8/Troy%20Snyder%20Help%20for%20the%20Discouraged%20(Ps%2034%2018)%2016e3726b0e55817aa88efc23706c768a.md)

[William Malenfant: “Become One Flock” (John 10:16)](Morning%20worships%20(WHQ)%2016e3726b0e5580e7a473d7afce9d8cf8/William%20Malenfant%20%E2%80%9CBecome%20One%20Flock%E2%80%9D%20(John%2010%2016)%2016e3726b0e5581a792f0ec911e80d8fb.md)

[William Malenfant: Comparing the Spiritual and Physical Person (1 Cor. 2:12-15)](Morning%20worships%20(WHQ)%2016e3726b0e5580e7a473d7afce9d8cf8/William%20Malenfant%20Comparing%20the%20Spiritual%20and%20Phys%2016e3726b0e55812e8119d723275634ea.md)

[William Malenfant: Elihu Patiently Listened (Jas. 1:19)](Morning%20worships%20(WHQ)%2016e3726b0e5580e7a473d7afce9d8cf8/William%20Malenfant%20Elihu%20Patiently%20Listened%20(Jas%201%20%2016e3726b0e55810cb9dbd279d163e9a0.md)

[William Malenfant: Learning a New Language (Neh. 13:24)](Morning%20worships%20(WHQ)%2016e3726b0e5580e7a473d7afce9d8cf8/William%20Malenfant%20Learning%20a%20New%20Language%20(Neh%2013%20%2016e3726b0e55812bb975ec67782ef4bd.md)

[William Malenfant: Morality in the Last Days (2 Tim. 3:13)](Morning%20worships%20(WHQ)%2016e3726b0e5580e7a473d7afce9d8cf8/William%20Malenfant%20Morality%20in%20the%20Last%20Days%20(2%20Tim%2016e3726b0e558123b39ce2158433a51a.md)

[William Malenfant: Sacrifice With a Willing Attitude (Ps. 54:6)](Morning%20worships%20(WHQ)%2016e3726b0e5580e7a473d7afce9d8cf8/William%20Malenfant%20Sacrifice%20With%20a%20Willing%20Attitud%2016e3726b0e558114a2a7d0a3ad5910f3.md)

[William Malenfant: Satan Is “the Father of the Lie” (John 8:44)](Morning%20worships%20(WHQ)%2016e3726b0e5580e7a473d7afce9d8cf8/William%20Malenfant%20Satan%20Is%20%E2%80%9Cthe%20Father%20of%20the%20Lie%E2%80%9D%2016e3726b0e55815b8a79eaea1c8266a9.md)

[William Malenfant: Showing Emotions Without Reservations (Rom. 12:15)](Morning%20worships%20(WHQ)%2016e3726b0e5580e7a473d7afce9d8cf8/William%20Malenfant%20Showing%20Emotions%20Without%20Reserva%2016e3726b0e5581449fcfc12ef0d69144.md)

[William Malenfant: Spiritually Mature Youths (Prov. 20:11)](Morning%20worships%20(WHQ)%2016e3726b0e5580e7a473d7afce9d8cf8/William%20Malenfant%20Spiritually%20Mature%20Youths%20(Prov%20%2016e3726b0e55816383f3c602d5c74597.md)

[William Malenfant: Use Your Talents Wisely (Matt. 25:30)](Morning%20worships%20(WHQ)%2016e3726b0e5580e7a473d7afce9d8cf8/William%20Malenfant%20Use%20Your%20Talents%20Wisely%20(Matt%2025%2016e3726b0e558121adbbeb9c3bb397f2.md)

[William Turner, Jr.: Can Endeavors Become Distractions? (John 11:5)](Morning%20worships%20(WHQ)%2016e3726b0e5580e7a473d7afce9d8cf8/William%20Turner,%20Jr%20Can%20Endeavors%20Become%20Distractio%2016e3726b0e558150ab30cc9c03aeef02.md)

[William Turner, Jr.: Comfort and Strengthen One Another (2 Thess. 2:16, 17)](Morning%20worships%20(WHQ)%2016e3726b0e5580e7a473d7afce9d8cf8/William%20Turner,%20Jr%20Comfort%20and%20Strengthen%20One%20Anot%2016e3726b0e558144a83ec3dfe1dda49c.md)

[William Turner, Jr.: Do Not Be Partial (John 4:31)](Morning%20worships%20(WHQ)%2016e3726b0e5580e7a473d7afce9d8cf8/William%20Turner,%20Jr%20Do%20Not%20Be%20Partial%20(John%204%2031)%2016e3726b0e5581ff9fa7c6c0b9f2d74c.md)

[William Turner, Jr.: Finding True Happiness (Matt. 5:8)](Morning%20worships%20(WHQ)%2016e3726b0e5580e7a473d7afce9d8cf8/William%20Turner,%20Jr%20Finding%20True%20Happiness%20(Matt%205%20%2016e3726b0e55819bacbfe6a559169bbe.md)

[William Turner, Jr.: “Jehovah Raises Up the Meek” (Ps. 147:6)](Morning%20worships%20(WHQ)%2016e3726b0e5580e7a473d7afce9d8cf8/William%20Turner,%20Jr%20%E2%80%9CJehovah%20Raises%20Up%20the%20Meek%E2%80%9D%20(P%2016e3726b0e55813685c9cc6975565e3f.md)

[William Turner, Jr.: Make Known “the Good News” (Rom. 1:16)](Morning%20worships%20(WHQ)%2016e3726b0e5580e7a473d7afce9d8cf8/William%20Turner,%20Jr%20Make%20Known%20%E2%80%9Cthe%20Good%20News%E2%80%9D%20(Rom%2016e3726b0e5581088ba7f29bc4f4e65a.md)

[William Turner, Jr.: What Makes Us Valuable to Jehovah? (1 Pet. 3:4)](Morning%20worships%20(WHQ)%2016e3726b0e5580e7a473d7afce9d8cf8/William%20Turner,%20Jr%20What%20Makes%20Us%20Valuable%20to%20Jehov%2016e3726b0e55813dbe26ef872440c707.md)